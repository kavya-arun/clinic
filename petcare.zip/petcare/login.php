<?php
session_start();
$_SESSION["logged_id"]=0;
$link = mysqli_connect("localhost", "root", "123456", "it") or die("Connection Error");
$user=$_POST['user'];
$password=$_POST['password'];
$query="select password from tlogin where username = '$user'";
$res=mysqli_query($link,$query) or die("ERROR");
$r=mysqli_fetch_array($res);
if($r[0]==$password){
session_start();
$_SESSION["username"]=$user;
$_SESSION["logged_id"]=1;
if($user=="username")
{
header("location:register.html");
}
else{
header("location:index1.html");
}
}
elseif($r[0]==NULL)
{
die("invalid user");
}
else
{
die ("invalid password");
}
?>
