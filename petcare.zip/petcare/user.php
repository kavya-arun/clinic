<?php
session_start();
if (!isset($_SESSION["sid"]))
{
	die("Login first");
}
else
{
header("Location:/IT/cal/index.html");
}
?>
