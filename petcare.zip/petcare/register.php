<?php
$link = mysqli_connect("localhost", "root", "123456", "it") or die("Connection Error");
$user=$_POST['user'];
$password=$_POST['password'];
$email=$_POST['email'];
$cpassword=$_POST['confirm'];
echo $user;
echo $password;
echo $email;
echo $cpassword;
if ($password==$cpassword){
$q1= "insert into tregister (username,password,email,cpassword) values ('$user','$password','$email','$cpassword')";
$result=mysqli_query($link,$q1) or die('SQL QUERY');
if($result)
{
$q2= "insert into tlogin (username,password) values ('$user','$password')";
$result1=mysqli_query($link,$q2) or die('Error in SQL INNER QUERY');
mail($to,$sub,$message,$header);
echo "<script>alert('Registeration complete!');window.location.href = 'login.html';</script>";
echo "<br />";
}
}
?>	

