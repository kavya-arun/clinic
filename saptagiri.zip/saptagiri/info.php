<html>
<body>
<label for="name"><b>Name</b></label>
    <input type="text" placeholder="Enter Name" name="name" required></br></br>
<label for="age"><b>Age</b></label>
    <input type="text" placeholder="Enter age" name="age" required></br></br>
<label for="sex"><b>Sex</b></label>
    <input type="text" placeholder="Male/Female" name="sex" required></br></br>
<label for="number"><b>Phone</b></label>
    <input type="text" placeholder="Phone" name="number" required></br></br>
</body>
</html>
