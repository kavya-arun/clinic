<?php

$connection = mysqli_connect('localhost','root','','saptagiri') or die (mysqli_error());


   if (!$connection)

  {

  die('Could not connect: ' . mysql_error());

  }

if(isset($_POST["submit"])){
$name = $_POST['name'];
$age = $_POST['age'];
$phone = $_POST['phone'];
$sex = $_POST['sex'];
$address = $_POST['address'];
    echo "Hello";

    if($name!= '' || $phone !=''){

$sql="INSERT INTO registration (name, age,phone,sex,address) VALUES ($name,$age,$phone,$sex,$address)";

echo "1 record added";
    }
    else
    {
        echo "Insertion Failed
            Some fields are Blank...";
    }

 
}


?>