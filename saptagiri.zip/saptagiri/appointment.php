<!DOCTYPE html>
<html>
<head>
<title>Today's Patients!</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  margin: 0;
}

/* Style the header */
.header {
    background-color: #f1f1f1;
    padding: 20px;
    
     .footer {
    background-color: #f1f1f1;
    padding: 10px;
    text-align: center;
}
body {
   background-image: url("5.jpg");
   background-color: #cccccc;
}
    
    input[type=submit] {
    background-color: #4CAF50;
    color: white;
    padding: 12px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    float: right;
}
    }
</style>
</head>
<body>
    
    <div class="header">
    <a href="logout.php">Logout</a>
        
    <center> <h1>Patient List and token numbers</h1></center>
</div>
   
    
    <input type="submit" value="Click here to get today's list">
    
    </body>
</html>
    