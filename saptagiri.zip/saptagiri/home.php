<!DOCTYPE html>
<html lang="en">
<head>
<title>Home</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* {
    box-sizing: border-box;
    font-family: Arial, Helvetica, sans-serif;
}
h2 {
    font-size: 30px;
    font-style: arial;
    color:White;


}


body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.button {
    background-color: blue;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
}

/* Style the top navigation bar */
.topnav {
    overflow: hidden;
    background-color: #333;
}

/* Style the topnav links */
.topnav a {
    float: left;
    display: block;
    color: #f2f2f2;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

/* Change color on hover */
.topnav a:hover {
    background-color: #ddd;
    color: black;
}

/* Style the content */
.content {
    background-image: url("home.jpg");
        background-size: cover;
    background-color: #ddd;
    padding: 10px;
    height: 600px; /* Should be removed. Only for demonstration */
}

/* Style the footer */
.footer {
    background-color: #f1f1f1;
    padding: 10px;
}
</style>
</head>
<body>

<div class="topnav">
  <a href="logout.php">Logout</a>
 <center><h2>Welcome Admin!</h2></center>

</div>

<div class="content">

</br>
</br>
</br>
</br>
</br>
</br>
</br>
</br>
</br>
</br>
<center>
  <a href="register.php" class="button">Make an appointment</a></br> </br> </br> </br>
  <a href="appointment.php" class="button">View Today's Appointments</a>

</center>
</div>

<div class="footer">
  <center><p>All Rights Reserved</p></center>
</div>

</body>
</html>
