<html>
<head>
<style>
body {
background-image: url("login.jpg");
}
#rcorners1 {
    border-radius: 25px;
    background: white;
    padding: 20px;
    width: 350px;
    height: 350px;
}
.container {
    padding: 16px;
}
input[type=text]:required, input[type=password]:required {

    padding: 12px ;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
}
.button {
    background-color: blue;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
}
</style>
</head>
<body>
<br>
<br>
<br>
<br>
<br>
<center>

<div id="rcorners1">
<h1>ADMIN LOGIN</h1>
<center>

  <div class="container">
<form action="" method="post">
    <label for="uname"><b>Username</b></label>
    <input type="text" placeholder="Enter Username" name="username" pattern="^[a-zA-Z]+$" title="Only Letters" required>
</br>
    <label for="psw"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="password" required>
</br>
<input type ="submit" value="Login" name="submit">
</br>
</br>
 <label>
      <input type="checkbox" checked="checked" name="remember"> Remember me
    </label>
</br>
</br>
<span class="psw"> <a href="#">Forgot password?</a></span>
    </center>
</form>

<?php
//session_start();
//$_SESSION["logged_id"]=0;
if(isset($_POST["submit"])){
 if(!empty($_POST['username']) && !empty($_POST['password'])){
$username = $_POST['username'];
 $password = $_POST['password'];

 //DB Connection
 $conn = new mysqli('localhost', 'root', '') or die("DIE");
 //Select DB From database
 $db = mysqli_select_db($conn, 'saptagiri') or die("database error");
$query = mysqli_query($conn, "SELECT * FROM login WHERE username='".$username."'AND password='".$password."'");
$numrows= mysqli_num_rows($query);
if($numrows!=0)
{

while($row= mysqli_fetch_assoc($query))
{
$dbusername=$row['username'];
$dbpassword=$row['password'];
}
if($username == $dbusername && $password == $dbpassword)
{
    
session_start();
$_SESSION["sess_user"]=$username;
//$_SESSION["logged_id"]=1;
    
    //if($username=="sess_user")
    //{
     // header("location:home.php");  
    //}
    
    //else
    //{
       // header("location:home.html");
   // }
 
    echo "<script type='text/javascript'> document.location = 'home.php';</script>";
}
else {
echo "Invalid username or password";
}
}
else
{
echo "Invalid User!";
}
}
}
?>







</div>
</body>
</html>
